<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="en">
<head>
<title>Multi Bright Forms a Flat Responsive Widget Template :: W3layouts</title>
<!-- Meta tag Keywords -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Multi Bright Forms Responsive Widget,Login form widgets, Sign up Web forms , Login signup Responsive web form,Flat Pricing table,Flat Drop downs,Registration Forms,News letter Forms,Elements" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Meta tag Keywords -->

<link href="css/login_style.css" type="text/css" rel="stylesheet" media="all">
<link rel="stylesheet" href="css/login_jquery-ui.css" type="text/css" media="all">

<!-- online fonts -->
<link href="//fonts.googleapis.com/css?family=Della+Respira" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Nova+Square" rel="stylesheet">
<!-- //online fonts -->

</head>
<body>
<section class="header">

		<div class="top-border">
			<div class="header-left">
				<div class="heading-left">
					<h2>register</h2>
				</div>
				<form action="#" method="post">
					<div class="heading-bottom-left">
						<div class="form-control"> 
							<label class="header">Full Name <span>:</span></label>
							<input type="text" id="name" name="name" placeholder="Full Name" title="Please enter your Full Name" required=""/>
						</div>
						<div class="form-control">	
							<label class="header">Password <span>:</span></label>
							<input type="password" id="pswd" name="password" placeholder="Password" title="Please enter a Valid Password" required=""/>
						</div>
						<div class="form-control"> 
							<label class="header">email <span>:</span></label>
							<input type="email" id="email" name="email" placeholder="Email" title="Please enter your Email" required=""/>
						</div>
					</div>
					<div class="heading-bottom-right">
						<div class="form-control">
							<label class="header">Date of birth <span>:</span></label>
							<input class="date" type="text" id="datepicker2"  name="datepicker2" placeholder="Date" title="Please enter your Date of birth" required=""/>
						</div>
						<div class="form-control">	
							<label class="header">confirm Password<span>:</span></label>
							<input type="password" id="pswd1" name="password" placeholder="Confirm password" title="Please enter a Valid Password" required=""/>
						</div>
						<div class="form-control"> 
							<label class="header">Place of Residence <span>:</span></label>
							<input type="text" id="residence" name="residence" placeholder="Residence" title="Please enter your Place of Residence" required=""/>
						</div>
					</div>
					<div class="clear"></div>
					<div class="register">
						<input type="submit" id="submit" name="Register" value="Register"/>
					</div>
					<div class="clear"></div>
				</form>
			</div>
			<div class="header-right">
				<div class="heading-right">
					<h3>login</h3>
				</div>
				<form action="#" method="post">
					<div class="form-control"> 
						<label class="header">User name <span>:</span></label>
						<input type="text" id="name1" name="name" placeholder="User Name" title="Please enter your Name" required=""/>
					</div>
					<div class="form-control w3">	
						<label class="header">Password <span>:</span></label>
						<input type="password" id="pswd2" name="password" placeholder="Password" title="Please enter a Valid Password" required=""/>
					</div>
					<label class="anim">
						<input type="checkbox" class="checkbox">
						<span> Stay logged in </span> 
					</label> 
					<div class="login">
						<input type="submit" id="submit1" name="Login" value="Login" />
					</div>
					<div class="clear"></div>
				</form>
			</div>
			<div class="clear"></div>
		</div>
		<!-- copyright -->
			<p class="agile-copyright">&copy; 2017 Multi Bright Forms. All Rights Reserved | Design by <a href="https://w3layouts.com/" target="_blank">W3layouts</a></p> 
		<!-- //copyright -->
</section>

<!-- Default-JavaScript -->
		<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<!-- //Default-JavaScript -->

		<!-- Date-Picker-JavaScript -->
				<script src="js/jquery-ui.js"></script>
				<script>
					$(function() {
						$( "#datepicker,#datepicker1,#datepicker2" ).datepicker();
					});
				</script>
		<!-- //Date-Picker-JavaScript -->
	<?php
        include 'lower_footer.php';
        ?>
</body>	
</html>