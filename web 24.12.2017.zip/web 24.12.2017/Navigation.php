<!doctype html>
<html>
<ul class="nav">
              <li><a href="index.php">Home</a></li>                  
              <li class="dropdown"><a href="reservation.php">Reservation</a>
                <ul class="dropdown2">
                  <li><a href="reservation.php">Pyman Suite</a></li>
                  <li><a href="reservation.php">Lushington Suite</a></li>
                  <li><a href="reservation.php">Wickwar Suite</a></li>
                  <li><a href="reservation.php">Taylor Suite</a></li>
                  <li><a href="reservation.php">Full Bungalow </a></li>
                </ul>
              </li>             
              <li class="dropdown"><a href="about.php">About</a></li>
           </li>           
           <li class="dropdown"><a href="offers.php">offers</a></li>        
            <li><a href="contact.php">Contact</a></li>
            <div class="clearfix"></div>
          </ul>
</html>