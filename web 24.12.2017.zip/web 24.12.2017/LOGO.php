<!doctype html>
<html>
<div class="logo">
					<h1><a href="index.php">Kirchhayn<span>Bungalow</span></a></h1>
				</div>	
</html>