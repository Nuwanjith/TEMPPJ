<html>
       	    <div class="header_bottom">
		 	  <div class="container">	 			
				<?php
				   
				  include'logo.php'; 
				  
				  ?>			
			<div class="navigation">	
			<div>
              <label class="mobile_menu" for="mobile_menu">
              <span>Menu</span>
              </label>
              <input id="mobile_menu" type="checkbox">
				<?php
				include 'navigation.php';
				?>
		</div>			
	 </div>
     <div class="clearfix"></div>		   
    </div>
   </div>	
   <div id="slider">
	  <div><img src="images/2.jpg" class="img-responsive" alt="img01"/></div>
	  <div><img src="images/1.jpg" class="img-responsive" alt="img02"/></div>
	  <div><img src="images/2.jpg" class="img-responsive" alt="img03"/></div>
	  <div><img src="images/1.jpg" class="img-responsive" alt="img04"/></div>
	</div>
  </div>
  

        <div class="main">        	
         <div class="container">          	 
	 		 <div class="row grids text-center">
				 <div class="col-md-4">
					<div class="view view-tenth">
					      <a href="single.html">
						   <div class="inner_content clearfix">
							<div class="product_image">
								<img src="images/pic1.jpg" class="img-responsive" alt=""/>
								<div class="label-product">
                                <span class="new">From 150$</span> </div>
								<div class="mask" >
			                        <h2>Room with one Bedroom</h2>
			                        <h3>A wonderful serenity has taken possession of my entire soul</h3>
			                        <div class="info"><i class="fa fa-search-plus"></i> </div>
			                    </div>
			                  	</div>
			                 </div>
				            </a> 
				       </div>
				       <div class="product_container wow bounceIn" data-wow-delay="0.4s">
						  <h3><a href="#">Room with one Bedroom</a></h3>
					      <div class="underheader-line"></div>
					      <ul class="person">
					      	<h4>Max Person:</h4>
					      	<li><i class="fa fa-male"> </i></li>
					      	<li><i class="fa fa-male"> </i></li>
					      	<li><i class="fa fa-male"> </i></li>
					      </ul>
					      <p>Beds:1 Single Bed</p>
				       </div>		
		            </div>
				    <div class="col-md-4">
					  <div class="view view-tenth">
					      <a href="single.html">
						   <div class="inner_content clearfix">
							 <div class="product_image">
								<img src="images/pic3.jpg" class="img-responsive" alt=""/>
								<div class="label-product">
                                <span class="new">From 160$</span> </div>
								<div class="mask">
			                        <h2>Family Spacious Room</h2>
			                        <h3>A wonderful serenity has taken possession of my entire soul</h3>
			                         <div class="info"><i class="fa fa-search-plus"></i> </div>
			                    </div>
			                  	</div>
			                   </div>
				            </a> 
				       </div>
				       <div class="product_container wow bounceIn" data-wow-delay="0.4s">
						  <h3><a href="#">Room with two Bedroom</a></h3>
					      <div class="underheader-line"></div>
					     <ul class="person">
					      	<h4>Max Person:</h4>
					      	<li><i class="fa fa-male"> </i></li>
					      	<li><i class="fa fa-male"> </i></li>
					      	<li><i class="fa fa-male"> </i></li>
					      </ul>
					      <p>Beds:2 Single Beds</p>
				       </div>		
		            </div>
				    <div class="col-md-4">
					   <div class="view view-tenth">
					      <a href="single.html">
						   <div class="inner_content clearfix">
							<div class="product_image">
								<img src="images/pic2.jpg" class="img-responsive" alt=""/>
								<div class="label-product">
                                <span class="new">From 150$</span> </div>
								<div class="mask">
			                        <h2>Room with one Bedroom</h2>
			                        <h3>A wonderful serenity has taken possession of my entire soul</h3>
			                         <div class="info"><i class="fa fa-search-plus"></i> </div>
			                    </div>
			                    </div>
			                  </div>
				            </a> 
				       </div>
				       <div class="product_container wow bounceIn" data-wow-delay="0.4s">
						  <h3><a href="#">King Size Bedroom</a></h3>
					      <div class="underheader-line"></div>
					     <ul class="person">
					      	<h4>Max Person:</h4>
					      	<li><i class="fa fa-male"> </i></li>
					      	<li><i class="fa fa-male"> </i></li>
					      	<li><i class="fa fa-male"> </i></li>
					      </ul>
					      <p>Beds:3 Single Beds</p>
				       </div>		
		            </div>
			 </div>	 
          </div>
          <div class="reservation wow fadeInLeft" data-wow-delay="0.4s" id="work">
          	<div class="container">
          		<div class="row">
          			<div class="col-md-9">
          				<div id="main-reservation-text"><h3>Call us <span>+1 2547 487 8974</span> or made reservation right now!</h3>
					       <p>vestibulum eu euismod quam nullam at accumsan orci aenean ullamcorper nulla ut sapien ultrices dignissim</p>
				        </div>
          			</div>
          			<div class="col-md-3">
          			  <a href="reservation.php" title="Online Reservation" class="btn btn-primary btn-normal btn-inline " target="_self">Online Reservation</a>
          			</div>
          		</div>
          	</div>
          </div>
          <div class="content-bottom wow fadeInLeft" data-wow-delay="0.4s" id="work">   
            <div class="container">   
        	    <div class="row">
				     <div class="col-md-8">
				     	 <div class="welcome_desc">
				       		<h3>Visitor Experienced</h3>
				            <div class="course_demo">
					          <ul id="flexiselDemo3">	
								<li><img src="images/v1.jpg" class="img-responsive" /><div class="desc">
									<h3>Lorem Ipsum</h3>
									<p>Lorem ipsum dolor<br> sit amet, consectetuer.</p>
								</div></li>
								<li><img src="images/v2.jpg" class="img-responsive" /><div class="desc">
									<h3>Lorem Ipsum</h3>
									<p>Lorem ipsum dolor<br> sit amet, consectetuer.</p>
								</div></li>
								<li><img src="images/v3.jpg" class="img-responsive" /><div class="desc">
									<h3>Lorem Ipsum</h3>
									<p>Lorem ipsum dolor<br> sit amet, consectetuer.</p>
								</div></li>
								<li><img src="images/v4.jpg" class="img-responsive" /><div class="desc">
									<h3>Lorem Ipsum</h3>
									<p>Lorem ipsum dolor<br> sit amet, consectetuer.</p>
								</div></li>
								<li><img src="images/v5.jpg" class="img-responsive" /><div class="desc">
									<h3>Lorem Ipsum</h3>
									<p>Lorem ipsum dolor<br> sit amet, consectetuer.</p>
								</div></li>		    	  	       	   	    	
							</ul>
				<script type="text/javascript">
			$(window).load(function() {
				$("#flexiselDemo3").flexisel({
					visibleItems: 4,
					animationSpeed: 1000,
					autoPlay: true,
					autoPlaySpeed: 3000,    		
					pauseOnHover: true,
					enableResponsiveBreakpoints: true,
			    	responsiveBreakpoints: { 
			    		portrait: { 
			    			changePoint:480,
			    			visibleItems: 1
			    		}, 
			    		landscape: { 
			    			changePoint:640,
			    			visibleItems: 2
			    		},
			    		tablet: { 
			    			changePoint:768,
			    			visibleItems: 2
			    		}
			    	}
			    });
			    
			});
		</script>
		<script type="text/javascript" src="js/jquery.flexisel.js"></script>
	            </div>
	       </div>
		</div>
		 <div class="col-md-4 middle_right">
			<h3>Info</h3>
			<ul id="general-info">
				<li><i class="fa fa-clock-o"> </i>Check-in: 14:00; Check-out: 12:00</li>
				<li><i class="fa fa-globe"> </i>Free Wi-Fi Internet in Rooms</li>
				<li><i class="fa fa-cutlery"> </i>In Room Dining Available from <br>06:00pm to 10:30pm</li>
				<li><i class="fa fa-truck"> </i>Local Self Parking: $20-$25 per night</li>
				<li><i class="fa fa-picture-o"> </i>Walking Distance to Wall Street, Battery Park and Brooklyn Bridge</li>
			</ul>	        
		  </div>
		 </div>
		</div>
		</div>
		       <div class="company_logos wow bounceIn" data-wow-delay="0.4s">
		          	<h3>Our Gallery</h3>
		          	 <div class="ocarousel_slider">  
	      				<div class="ocarousel example_photos" data-ocarousel-perscroll="3">
			                <div class="ocarousel_window">
			                   <a href="#" title="Hp"> <img src="images/g1.jpg" class="img-responsive" alt="" /></a>
			                   <a href="#" title="Bosch"><img src="images/g2.jpg" class="img-responsive" alt="" /></a>
			                   <a href="#" title="El pso"><img src="images/g3.jpg" class="img-responsive" alt="" /></a>
			                   <a href="#" title="Print X Press"><img src="images/g4.jpg" class="img-responsive" alt="" /></a>
			                   <a href="#" title="Arcelo mittal"><img src="images/g5.jpg" class="img-responsive" alt="" /></a>
			                    <a href="#" title="Goldware IT Services"><img src="images/g6.jpg" class="img-responsive" alt="" /></a>
			                   <a href="#" title="Lucent Technologies"><img src="images/g7.jpg" class="img-responsive" alt="" /></a>
			                   <a href="#" title="ge"><img src="images/g8.jpg" class="img-responsive" alt="" /></a>
			                </div>
			               <span>           
			                <a href="#" data-ocarousel-link="left" class="prev"><i class="fa fa-angle-left"></i> </a>
			                <a href="#" data-ocarousel-link="right" class="next"> <i class="fa fa-angle-right"></i></a>
			               </span>
					   </div>
				     </div>      		
              </div>
        </div>
        <div class="footer">
         <div class="container">   	 
           	 <div class="footer_top">
           	 	<div class="row">
           	 	   <div class="col-md-4 footer_grid">
           	 			<h4>Receive our Newsletter</h4>
           	 			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
           	 			<div class="search">
						  <form>
							   <input type="text" value="">
							   <input type="submit" value="">
						  </form>
					    </div>
           	 		</div>
           	 		<div class="col-md-4 footer_grid">
           	 			<h4>Twitter Feed</h4>
           	 			<div class="footer-list">
						 <ul>
							<li class="list_top"><i class="fa fa-twitter twt"></i>
							<p>Lorem ipsum <span class="yellow"><a href="#">consectetuer</a></span>vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatu</li></p>
							<li><i class="fa fa-twitter twt"></i>
							<p>Lorem ipsum <span class="yellow"><a href="#">consectetuer</a></span>vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatu</li></p>
		                 </ul>
					    </div>
           	 		</div>
           	 		<div class="col-md-4 footer_grid">
           	 			<h4>Our Address</h4>
           	 			<div class="company_address">
				     	        <p>500 Lorem Ipsum Dolor Sit,</p>
						   		<p>22-56-2-9 Sit Amet, Lorem,</p>
						   		<p>USA</p>
				   		<p>Phone:(00) 222 666 444</p>
				   		<p>Fax: (000) 000 00 00 0</p>
				 	 	<p>Email: <span><a href="mailto:info@mycompany.com">info(at)mycompany.com</a></span></p>
				   		</div>
				      <ul class="socials">
                        <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                        <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                      </ul>
           	 		</div>
           	 		<div class="clearfix"></div>
           	     </div>
           	  </div>
              <div class="footer_bottom">
		           <div class="copy_right">
						<p>&copy; 2013 All Rights Reseverd Designed by <a href="http://w3layouts.com/">W3layouts</a> </p>
				   </div>
				   <div class="footer_nav">
				   	 <ul>
				   	 	<li><a href="index.php">Home</a></li>
				   	 	<li><a href="#">Terms of use</a></li>
				   	 	<li><a href="#">Privacy Policy</a></li>
				   	 	<li><a href="contact.php">Contact</a></li>
				   	 </ul>
				    </div>
				  <div class="clearfix"></div>
				</div>
		   </div>
   </div>
</body>
</html>

